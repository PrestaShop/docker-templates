<?php return array (
  'parameters' => 
  array (
    'database_host' => '127.0.0.1',
    'database_port' => '',
    'database_name' => 'prestashop',
    'database_user' => 'root',
    'database_password' => 'admin',
    'database_prefix' => 'ps_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => NULL,
    'mailer_password' => NULL,
    'secret' => 'HKkdfO3IfUTFUtvIDbYZvtyKSnSX2MRKGjfqXdQATqxQaEQn8SUIIWqO',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2017-07-19',
    'locale' => 'fr-FR',
    'cookie_key' => 'EWeXivPVpMVjnvJ3LrydytCznUcN5NyhCry6P5GYpP76HeMYVSeEBsNw',
    'cookie_iv' => 'MSqqVe79',
    'new_cookie_key' => 'def00000fd715d580c816926475a5c99e53fb4e232d808e7912da09dd4828127fcdd1c478d9570ee245396674e10ebfebf0667615a6964cfed6d24e396eb01cb7c210027',
  ),
);
